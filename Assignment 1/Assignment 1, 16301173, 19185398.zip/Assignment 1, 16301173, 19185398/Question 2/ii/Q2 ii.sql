UPDATE Staff SET fName = 'Marcus', lName = 'Belcastro', DOB = '1999-01-01'
WHERE fName = 'Julie' AND lName = 'Lee';

UPDATE Staff SET fName = 'Heja', lName = 'Bibani'
WHERE staffNo = 'SL21';

SELECT * FROM Staff;
