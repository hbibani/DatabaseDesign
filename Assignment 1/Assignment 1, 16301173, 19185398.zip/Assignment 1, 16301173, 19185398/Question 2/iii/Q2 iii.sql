SELECT fName, lName, telNo, maxRent
FROM Client;
